immutable_var = 1, 2, 3, True, "Стрингзпт"
print(immutable_var)
immutable_var[0]= 200
print(immutable_var)
# Мы не можем изменить кортеж, потому что это неизменяемый объект в пониманнии Пайтон
# и он не поддерживает обращение по элементам
mutable_list = ([1, 2, 3], True, 'Стрингзпт')
mutable_list[0][0] = 5
print(mutable_list)