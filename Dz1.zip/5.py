Str = ('Неиропластичность')
Len = (len(Str))
Last_step = (Str[1:Len-1:])
print(Last_step[::-1])