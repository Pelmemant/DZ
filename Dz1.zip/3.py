Str = ('Кенгуру')
Len = (len(Str))
Half = (Len//2)
print(Str[Half:Len]+Str[:Half])