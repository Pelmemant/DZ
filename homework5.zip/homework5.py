my_list = [1, 2, 3, 4, 5, 6]
print('Список ' + str(my_list))
print('Первый элемент ' + str(my_list[0]))
print('Последний элемент ' + str(my_list[-1]))
print('Содержимое списка ' + str(my_list[2:-1]))
my_list[2] = 7
print('Список ' + str(my_list))

# ------------------------------------------------------------------------------
my_dict = {'Один': 'one', 'Два': 'two', 'Три': 'three', 'Четыре': 'forth', 'Пять': 'five'}
print('Словарь ' + str(my_dict))
print('Значение ' + str(my_dict.get('Три')))
my_dict['Шесть'] = 'six'
print('Улучшенный словарь ' + str(my_dict))
