Name = ('Vasil')
print('Name: ' + Name)
Age = (26)
print('Age: ' + str(Age))
Age = (27)
Is_Student = True
print('New Age: ' + str(Аge))
print('Is Student: ' + str(Is_Student))
