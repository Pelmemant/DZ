Name = ('Vasil')
Age = (26)
New_age = (Age + 1)
Is_Student = True
print('Name: ' + Name)
print('Age: ' + str(Age))
print('New Age: ' + str(New_age))
print('Is Student: ' + str(Is_Student))
