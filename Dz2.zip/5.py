# Автоматизируем простоту!
print('Сколько раз?')
Time = int(input())
print('Что именно?')
What = input()
print(('Обожаю писать ' + What + ' ,') * Time)